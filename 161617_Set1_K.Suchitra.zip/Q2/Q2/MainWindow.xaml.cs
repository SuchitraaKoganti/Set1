﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Q2
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void button_Display_Click(object sender, RoutedEventArgs e)
        {
            //Creating a object
            Sep19CHNEntities contextobj = new Sep19CHNEntities();
            if (txt_patstate.Text != string.Empty)  // Whether textbox is empty or not
            {
                var query = from Patient pat in contextobj.Patients
                            where pat.patstate == txt_patstate.Text  //Query to filter patient details by state
                            select pat;
                List<Patient> elist = new List<Patient>();
                elist = query.ToList<Patient>();
                if (elist.Count <= 0) MessageBox.Show("No records found");  
                else
                    dgd_patient.ItemsSource = query.ToList();
            }
            else MessageBox.Show("Please enter location");
        }
    }
}
