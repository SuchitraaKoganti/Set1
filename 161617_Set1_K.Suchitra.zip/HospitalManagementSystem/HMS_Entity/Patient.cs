﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HMS_Entity
{
    /// <summary>
    /// Patient ID : Developers Patient ID
    /// Patient Name : Developers Patient Name
    /// Description : This is an Entity Class for Patient
    /// Date of Modification : 17th Oct 2018
    /// </summary>
    public class Patient
    {
        public int PatientId { get; set; }
        public string PatientFirstName { get; set; }
        public string Patientgender { get; set; }
        public string PatientLastName { get; set; }
        public string Patientaddress { get; set; }
        public string Patientcity { get; set; }
        public string Patientstate { get; set; }
        public int Patientpincode { get; set; }
        public long PatientPhno { get; set; }
    }
}
