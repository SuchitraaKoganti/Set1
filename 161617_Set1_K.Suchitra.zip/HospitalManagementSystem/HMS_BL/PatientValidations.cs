﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using HMS_Entity;       //    Adding reference entity
using HMS_Exception;     // Adding reference Exception
using HMS_DAL;          // adding reference data access layer

namespace HMS_BL
{
    /// <summary>
    /// Patient ID : Patient ID
    /// Patient Name : Developer Patient Name
    /// Description : This class will have business logic for patient
    /// Date of Modification : 17th Oct 2018
    /// </summary>
    public class PatientValidations
    {
        PatientOperations patOperation;
        // Validating patient
        public static bool ValildatePatient(Patient pat)
        {
            bool patValidated = true;
            StringBuilder message = new StringBuilder();

            try
            {
                //To validate each detail with respect to validations whether every detail is fill or not
                if (pat.PatientFirstName.ToString().Equals(string.Empty) )
                {
                    patValidated = false;
                    message.Append(Environment.NewLine + "Patient name is Required and cannot be empty");
                }
                if (pat.PatientLastName.ToString().Equals(string.Empty))
                {
                    patValidated = false;
                    message.Append(Environment.NewLine + "Patient last name is Required and cannot be empty");
                }
                if (pat.PatientPhno < 1000000000 || pat.PatientPhno > 9999999999)
                {
                    message.Append("Patient Phone number should be 10 digits long\n");
                    patValidated = false;
                }
                if (pat.Patientaddress.ToString().Equals(string.Empty))
                {
                    message.Append(Environment.NewLine + "Patient address is Required and cannot be empty");
                    patValidated = false;
                }
                if (pat.Patientcity.ToString().Equals(string.Empty))
                {
                    message.Append(Environment.NewLine + "Patient city is Required and cannot be empty");
                    patValidated = false;
                }
                if (pat.Patientstate.ToString().Equals(string.Empty))
                {
                    message.Append(Environment.NewLine + "Patient state is Required and cannot be empty");
                    patValidated = false;
                }
                if (pat.Patientgender.ToString().Equals(string.Empty))
                {
                    message.Append(Environment.NewLine + "Patient gender is Required and cannot be empty");
                    patValidated = false;
                }
                if (pat.Patientpincode < 100000 || pat.Patientpincode > 999999)
                {
                    message.Append("Patient pincode should be 6 digits long\n");
                    patValidated = false;
                }

                if (patValidated == false)
                {
                    throw new PatientException(message.ToString());
                }
            }
            catch (PatientException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return patValidated;
        }

        //Add Patient
        public int AddPatient_BLL(Patient newpat)
        {
            int rowsAffected = 0;
            PatientOperations operationObj;
            try
            {
                if (ValildatePatient(newpat))
                {
                    operationObj = new PatientOperations();
                    rowsAffected = operationObj.AddPatient_DAL(newpat);
                }
            }
            catch (PatientException ex) { throw ex; }
            catch (SqlException se) { throw se; }
            catch (Exception ex) { throw ex; }
            return rowsAffected;

        }
        //Display Patient
        public DataTable GetPatient_BLL()
        {
            DataTable dtEmp;
            try
            {
                patOperation = new PatientOperations();
                dtEmp = patOperation.GetPatient_DAL();
            }
            catch (SqlException se)
            {

                throw se;
            }
            catch (Exception ex)
            {

                throw ex;
            }
            return dtEmp;
        }
    }
}
