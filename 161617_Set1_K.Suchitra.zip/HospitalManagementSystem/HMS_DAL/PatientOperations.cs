﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using HMS_Entity;  //Adding Entity Library
using HMS_Exception; //adding Exception Library
namespace HMS_DAL
{
    /// <summary>
    /// Patient ID : Patient ID
    /// Patient Name : Developer Patient Name
    /// Description : This class will have operations for patient
    /// Date of Modification : 17th Oct 2018
    /// </summary>
    public class PatientOperations
    {

        static string patConnStr = ConfigurationManager.ConnectionStrings["conStr"].ToString();
        static SqlConnection patConnObj;
        SqlCommand patCommand;
        DataTable dtDept, dtpat;    //Creating a datatable
        SqlDataReader patReader = null;    //Initialising a variable to read data
        public PatientOperations()
        {
            patConnObj = new SqlConnection(); //Establiching connection
            patConnObj.ConnectionString = patConnStr;
        }
        public int AddPatient_DAL(Patient pat)
        {
            int rowsAffected = 0;
            try
            {


                patCommand = new SqlCommand("Suchitraa.usp_AddPatient", patConnObj);
                patCommand.CommandType = CommandType.StoredProcedure;//@pfname,@plname,@pgender,@paddr,@pcity,@pstate,@ppin,@pph
                patCommand.Parameters.AddWithValue("@pfname", pat.PatientFirstName); // adding values as parameters
                patCommand.Parameters.AddWithValue("@plname", pat.PatientLastName);
                patCommand.Parameters.AddWithValue("@pgender",pat.Patientgender);
                patCommand.Parameters.AddWithValue("@paddr", pat.Patientaddress);
                patCommand.Parameters.AddWithValue("@pcity", pat.Patientcity);
                patCommand.Parameters.AddWithValue("@pstate", pat.Patientstate);
                patCommand.Parameters.AddWithValue("@ppin", pat.Patientpincode);
                patCommand.Parameters.AddWithValue("@pph", pat.PatientPhno);
                patConnObj.Open();
                rowsAffected = patCommand.ExecuteNonQuery();

            }
            catch (SqlException)
            {

                throw;
            }
            catch (Exception)
            {

                throw;
            }
            finally
            {
                if (patConnObj.State == ConnectionState.Open) patConnObj.Close();
            }
            return rowsAffected;

        }
        public DataTable GetPatient_DAL()
        {
            try
            {
                dtpat = new DataTable();
                patCommand = new SqlCommand("Suchitraa.usp_DisplayPatient", patConnObj); //To pass the query from sql
                patCommand.CommandType = CommandType.StoredProcedure;
                patConnObj.Open();  //Open the connection
                patReader = patCommand.ExecuteReader();
                if (patReader.HasRows)
                {
                    dtpat.Load(patReader);
                }
            }
            catch (SqlException)
            {

                throw;
            }
            catch (Exception)
            {

                throw;
            }
            finally
            {
                patReader.Close();
                if (patConnObj.State == ConnectionState.Open) patConnObj.Close();
            }
            return dtpat;
        }

    }
}
