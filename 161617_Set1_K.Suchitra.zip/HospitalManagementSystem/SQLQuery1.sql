create table Suchitraa.Patient
(
patid int identity(10,1) primary key,
patfname varchar(20),
patlname varchar(20),
patgender varchar(20),
pataddr varchar(50),
patcity varchar(20),
patstate varchar(20),
patpincode int,
patphno bigint
)
insert into Suchitraa.Patient values('Suchitra','Koganti','Female','H-no:123 Kukatpally','Hyderabad','Telangana',500072,9632587415)
insert into Suchitraa.Patient values('Geeta','Paidi','Female','H-no:123 Miyapur','BACD','Maharastra',500472,9645697415)
select * from Suchitraa.Patient

create proc Suchitraa.usp_AddPatient
@pfname varchar(20),
@plname varchar(20),
@pgender varchar(10),
@paddr varchar(50),
@pcity varchar(20),
@pstate varchar(20),@ppin int,@pph bigint
as
begin
insert into Suchitraa.Patient values(@pfname,@plname,@pgender,@paddr,@pcity,@pstate,@ppin,@pph)
end

create proc Suchitraa.usp_DisplayPatient
as
begin
select * from Suchitraa.Patient
end

select IDENT_CURRENT('Suchitraa.Patient')+ident_incr('Suchitraa.Patient')