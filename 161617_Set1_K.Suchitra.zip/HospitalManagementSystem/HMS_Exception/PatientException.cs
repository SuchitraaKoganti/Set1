﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HMS_Exception
{
    /// <summary>
    /// Patient ID : Developers Patient ID
    /// Patient Name : Developers Patient Name
    /// Description : This is an user defined exception Class for Patient
    /// Date of Modification : 17th Oct 2018
    /// </summary>
    public class PatientException: ApplicationException
    {
        public PatientException()
            : base()
        { }

        public PatientException(string Message) : base(Message)
        { }
    }
}
